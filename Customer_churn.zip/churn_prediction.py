"""
============================================================
  Customer Churn Prediction — Telco Dataset
  Tools: Python · Pandas · Scikit-learn · Matplotlib · Seaborn
  Models: Logistic Regression  |  Random Forest
============================================================
"""

import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    confusion_matrix, classification_report,
    accuracy_score, roc_auc_score, roc_curve, ConfusionMatrixDisplay
)

print("=" * 60)
print("  Customer Churn Prediction — Full ML Pipeline")
print("=" * 60)

# ─────────────────────────────────────────────
# STEP 1 ▶  LOAD DATA
# ─────────────────────────────────────────────
print("\n📂 STEP 1: Loading Dataset")
print("-" * 40)

df = pd.read_csv("telco_churn.csv")
print(f"   Shape        : {df.shape[0]:,} rows × {df.shape[1]} columns")
print(f"   Churn (Yes)  : {(df['Churn']=='Yes').sum():,}  ({(df['Churn']=='Yes').mean():.1%})")
print(f"   Churn (No)   : {(df['Churn']=='No').sum():,}  ({(df['Churn']=='No').mean():.1%})")


# ─────────────────────────────────────────────
# STEP 2 ▶  DATA CLEANING
# ─────────────────────────────────────────────
print("\n🧹 STEP 2: Data Cleaning")
print("-" * 40)

# Drop customerID (not a feature)
df.drop(columns=["customerID"], inplace=True)

# TotalCharges may have spaces → convert to numeric
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")

# Fill nulls in TotalCharges with median (new customers have 0 tenure)
missing_before = df["TotalCharges"].isna().sum()
df["TotalCharges"].fillna(df["TotalCharges"].median(), inplace=True)
print(f"   TotalCharges nulls fixed : {missing_before}")

# No other nulls expected
print(f"   Remaining nulls          : {df.isnull().sum().sum()}")
print(f"   Duplicate rows           : {df.duplicated().sum()}")
df.drop_duplicates(inplace=True)
print(f"   Final shape              : {df.shape}")


# ─────────────────────────────────────────────
# STEP 3 ▶  FEATURE ENCODING
# ─────────────────────────────────────────────
print("\n🔢 STEP 3: Feature Encoding")
print("-" * 40)

# Binary target: Churn Yes=1, No=0
df["Churn"] = (df["Churn"] == "Yes").astype(int)

# Identify column types
binary_cols    = ["gender", "Partner", "Dependents", "PhoneService",
                  "PaperlessBilling"]
multicat_cols  = ["MultipleLines", "InternetService", "OnlineSecurity",
                  "OnlineBackup", "DeviceProtection", "TechSupport",
                  "StreamingTV", "StreamingMovies", "Contract", "PaymentMethod"]
numeric_cols   = ["SeniorCitizen", "tenure", "MonthlyCharges", "TotalCharges"]

le = LabelEncoder()
for col in binary_cols:
    df[col] = le.fit_transform(df[col])
    print(f"   Label encoded  : {col}")

df = pd.get_dummies(df, columns=multicat_cols, drop_first=True)
print(f"   One-hot encoded: {len(multicat_cols)} categorical columns")
print(f"   Final feature count: {df.shape[1] - 1}")


# ─────────────────────────────────────────────
# STEP 4 ▶  TRAIN / TEST SPLIT  +  SCALING
# ─────────────────────────────────────────────
print("\n✂️  STEP 4: Train/Test Split")
print("-" * 40)

X = df.drop("Churn", axis=1)
y = df["Churn"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)

print(f"   Training samples : {X_train.shape[0]:,}")
print(f"   Testing  samples : {X_test.shape[0]:,}")
print(f"   Features         : {X_train.shape[1]}")


# ─────────────────────────────────────────────
# STEP 5 ▶  MODEL TRAINING
# ─────────────────────────────────────────────
print("\n🤖 STEP 5: Model Training")
print("-" * 40)

# — Logistic Regression —
lr_model = LogisticRegression(max_iter=1000, random_state=42)
lr_model.fit(X_train_sc, y_train)
print("   ✅  Logistic Regression trained")

# — Random Forest —
rf_model = RandomForestClassifier(
    n_estimators=200, max_depth=10,
    min_samples_leaf=5, random_state=42, n_jobs=-1
)
rf_model.fit(X_train, y_train)
print("   ✅  Random Forest trained (200 trees, max_depth=10)")


# ─────────────────────────────────────────────
# STEP 6 ▶  EVALUATION
# ─────────────────────────────────────────────
print("\n📊 STEP 6: Model Evaluation")
print("-" * 40)

def evaluate(name, model, X_t, y_t, proba=None):
    y_pred = model.predict(X_t)
    acc    = accuracy_score(y_t, y_pred)
    auc    = roc_auc_score(y_t, proba if proba is not None else model.predict_proba(X_t)[:,1])
    print(f"\n   ── {name} ──")
    print(f"   Accuracy : {acc:.4f}  ({acc*100:.2f}%)")
    print(f"   ROC-AUC  : {auc:.4f}")
    print(f"\n   Classification Report:")
    report = classification_report(y_t, y_pred, target_names=["No Churn","Churn"])
    for line in report.split("\n"):
        print(f"     {line}")
    return y_pred, acc, auc

lr_prob  = lr_model.predict_proba(X_test_sc)[:,1]
rf_prob  = rf_model.predict_proba(X_test)[:,1]

lr_pred, lr_acc, lr_auc = evaluate("Logistic Regression", lr_model, X_test_sc, y_test, lr_prob)
rf_pred, rf_acc, rf_auc = evaluate("Random Forest",       rf_model, X_test,    y_test, rf_prob)

# Cross-validation
print("\n   📐 5-Fold Cross-Validation (accuracy):")
cv_lr = cross_val_score(LogisticRegression(max_iter=1000, random_state=42),
                        X_train_sc, y_train, cv=5, scoring="accuracy")
cv_rf = cross_val_score(RandomForestClassifier(n_estimators=100, random_state=42),
                        X_train,    y_train, cv=5, scoring="accuracy")
print(f"     Logistic Regression : {cv_lr.mean():.4f} ± {cv_lr.std():.4f}")
print(f"     Random Forest       : {cv_rf.mean():.4f} ± {cv_rf.std():.4f}")


# ─────────────────────────────────────────────
# STEP 7 ▶  VISUALIZATIONS  (single figure)
# ─────────────────────────────────────────────
print("\n🎨 STEP 7: Generating Visualizations...")

plt.style.use("seaborn-v0_8-whitegrid")
DARK   = "#0f172a"
ACCENT = "#6366f1"
GREEN  = "#10b981"
RED    = "#ef4444"
GOLD   = "#f59e0b"
WHITE  = "#f8fafc"

fig = plt.figure(figsize=(20, 22), facecolor=DARK)
fig.suptitle("Customer Churn Prediction — ML Report",
             fontsize=22, fontweight="bold", color=WHITE, y=0.98)

gs = gridspec.GridSpec(4, 3, figure=fig, hspace=0.45, wspace=0.35,
                       left=0.06, right=0.97, top=0.95, bottom=0.04)

# ── 1. Churn distribution ──────────────────────────────────
ax1 = fig.add_subplot(gs[0, 0])
churn_counts = pd.Series(y).value_counts()
bars = ax1.bar(["No Churn", "Churn"], churn_counts.values,
               color=[GREEN, RED], edgecolor="none", width=0.55)
ax1.set_title("Churn Distribution", color=WHITE, fontweight="bold")
ax1.set_facecolor(DARK); ax1.tick_params(colors=WHITE)
for spine in ax1.spines.values(): spine.set_visible(False)
for bar, val in zip(bars, churn_counts.values):
    ax1.text(bar.get_x()+bar.get_width()/2, bar.get_height()+50,
             f"{val:,}\n({val/len(y)*100:.1f}%)",
             ha="center", va="bottom", color=WHITE, fontsize=10, fontweight="bold")
ax1.set_ylim(0, churn_counts.max()*1.2)
ax1.yaxis.label.set_color(WHITE)

# ── 2. Tenure distribution by churn ───────────────────────
ax2 = fig.add_subplot(gs[0, 1])
orig_df = pd.read_csv("telco_churn.csv")
orig_df["TotalCharges"] = pd.to_numeric(orig_df["TotalCharges"], errors="coerce")
for label, color, ls in [("No", GREEN, "-"), ("Yes", RED, "--")]:
    subset = orig_df[orig_df["Churn"] == label]["tenure"]
    ax2.hist(subset, bins=30, alpha=0.65, color=color, label=f"Churn={label}", density=True)
ax2.set_title("Tenure Distribution by Churn", color=WHITE, fontweight="bold")
ax2.set_xlabel("Tenure (months)", color=WHITE)
ax2.set_facecolor(DARK); ax2.tick_params(colors=WHITE)
for spine in ax2.spines.values(): spine.set_visible(False)
ax2.legend(facecolor="#1e293b", labelcolor=WHITE, framealpha=0.8)

# ── 3. Monthly Charges by Churn ────────────────────────────
ax3 = fig.add_subplot(gs[0, 2])
data_no  = orig_df[orig_df["Churn"]=="No"]["MonthlyCharges"]
data_yes = orig_df[orig_df["Churn"]=="Yes"]["MonthlyCharges"]
bp = ax3.boxplot([data_no, data_yes], patch_artist=True,
                 widths=0.5, medianprops=dict(color=WHITE, linewidth=2))
for patch, color in zip(bp["boxes"], [GREEN, RED]):
    patch.set_facecolor(color); patch.set_alpha(0.75)
for element in ["whiskers","caps","fliers"]:
    for item in bp[element]: item.set(color=WHITE, alpha=0.5)
ax3.set_xticklabels(["No Churn","Churn"], color=WHITE)
ax3.set_title("Monthly Charges vs Churn", color=WHITE, fontweight="bold")
ax3.set_ylabel("Monthly Charges ($)", color=WHITE)
ax3.set_facecolor(DARK); ax3.tick_params(colors=WHITE)
for spine in ax3.spines.values(): spine.set_visible(False)

# ── 4. Confusion Matrix — Logistic Regression ─────────────
ax4 = fig.add_subplot(gs[1, 0])
cm_lr = confusion_matrix(y_test, lr_pred)
sns.heatmap(cm_lr, annot=True, fmt="d", cmap="Blues", ax=ax4,
            xticklabels=["No Churn","Churn"], yticklabels=["No Churn","Churn"],
            cbar_kws={"shrink": 0.8})
ax4.set_title(f"Confusion Matrix\nLogistic Regression (Acc: {lr_acc:.2%})",
              color=WHITE, fontweight="bold")
ax4.set_xlabel("Predicted", color=WHITE); ax4.set_ylabel("Actual", color=WHITE)
ax4.set_facecolor(DARK); ax4.tick_params(colors=WHITE)

# ── 5. Confusion Matrix — Random Forest ───────────────────
ax5 = fig.add_subplot(gs[1, 1])
cm_rf = confusion_matrix(y_test, rf_pred)
sns.heatmap(cm_rf, annot=True, fmt="d", cmap="Greens", ax=ax5,
            xticklabels=["No Churn","Churn"], yticklabels=["No Churn","Churn"],
            cbar_kws={"shrink": 0.8})
ax5.set_title(f"Confusion Matrix\nRandom Forest (Acc: {rf_acc:.2%})",
              color=WHITE, fontweight="bold")
ax5.set_xlabel("Predicted", color=WHITE); ax5.set_ylabel("Actual", color=WHITE)
ax5.set_facecolor(DARK); ax5.tick_params(colors=WHITE)

# ── 6. ROC Curves ─────────────────────────────────────────
ax6 = fig.add_subplot(gs[1, 2])
for prob, name, color, auc in [
    (lr_prob, "Logistic Regression", ACCENT, lr_auc),
    (rf_prob, "Random Forest",       GOLD,   rf_auc)
]:
    fpr, tpr, _ = roc_curve(y_test, prob)
    ax6.plot(fpr, tpr, color=color, lw=2.5, label=f"{name} (AUC={auc:.3f})")
ax6.plot([0,1],[0,1], color="gray", lw=1.5, ls="--", label="Random Baseline")
ax6.fill_between(*roc_curve(y_test, rf_prob)[:2], alpha=0.08, color=GOLD)
ax6.set_title("ROC Curves", color=WHITE, fontweight="bold")
ax6.set_xlabel("False Positive Rate", color=WHITE)
ax6.set_ylabel("True Positive Rate", color=WHITE)
ax6.set_facecolor(DARK); ax6.tick_params(colors=WHITE)
for spine in ax6.spines.values(): spine.set_color("#334155")
ax6.legend(facecolor="#1e293b", labelcolor=WHITE, framealpha=0.8, fontsize=9)

# ── 7. Feature Importance (Random Forest top-15) ──────────
ax7 = fig.add_subplot(gs[2, :2])
feat_imp = pd.Series(rf_model.feature_importances_, index=X.columns)
top15    = feat_imp.sort_values(ascending=True).tail(15)
colors   = [ACCENT if v > top15.mean() else "#475569" for v in top15.values]
bars7    = ax7.barh(top15.index, top15.values, color=colors, edgecolor="none", height=0.65)
ax7.set_title("Top-15 Feature Importances (Random Forest)", color=WHITE, fontweight="bold")
ax7.set_xlabel("Importance Score", color=WHITE)
ax7.set_facecolor(DARK); ax7.tick_params(colors=WHITE)
for spine in ax7.spines.values(): spine.set_visible(False)
for bar, val in zip(bars7, top15.values):
    ax7.text(val + 0.001, bar.get_y()+bar.get_height()/2,
             f"{val:.4f}", va="center", color=WHITE, fontsize=8)

# ── 8. Model Comparison Bar Chart ─────────────────────────
ax8 = fig.add_subplot(gs[2, 2])
metrics  = ["Accuracy", "ROC-AUC"]
lr_vals  = [lr_acc, lr_auc]
rf_vals  = [rf_acc, rf_auc]
x        = np.arange(len(metrics))
w        = 0.35
ax8.bar(x - w/2, lr_vals, w, color=ACCENT, label="Logistic Regression", alpha=0.85)
ax8.bar(x + w/2, rf_vals, w, color=GOLD,   label="Random Forest",       alpha=0.85)
ax8.set_xticks(x); ax8.set_xticklabels(metrics, color=WHITE)
ax8.set_ylim(0.7, 1.0)
ax8.set_title("Model Comparison", color=WHITE, fontweight="bold")
ax8.set_facecolor(DARK); ax8.tick_params(colors=WHITE)
for spine in ax8.spines.values(): spine.set_visible(False)
for bars in [ax8.containers[0], ax8.containers[1]]:
    ax8.bar_label(bars, fmt="%.3f", color=WHITE, fontsize=9, padding=3)
ax8.legend(facecolor="#1e293b", labelcolor=WHITE, framealpha=0.8, fontsize=9)

# ── 9. CV Accuracy Scores ─────────────────────────────────
ax9 = fig.add_subplot(gs[3, :])
ax9.plot(range(1,6), cv_lr, "o-", color=ACCENT, lw=2.5, ms=8, label="Logistic Regression")
ax9.plot(range(1,6), cv_rf, "s-", color=GOLD,   lw=2.5, ms=8, label="Random Forest")
ax9.axhline(cv_lr.mean(), color=ACCENT, ls="--", alpha=0.5, lw=1.5,
            label=f"LR Mean: {cv_lr.mean():.4f}")
ax9.axhline(cv_rf.mean(), color=GOLD,   ls="--", alpha=0.5, lw=1.5,
            label=f"RF Mean: {cv_rf.mean():.4f}")
ax9.fill_between(range(1,6), cv_lr, cv_lr.mean(), alpha=0.08, color=ACCENT)
ax9.fill_between(range(1,6), cv_rf, cv_rf.mean(), alpha=0.08, color=GOLD)
ax9.set_title("5-Fold Cross-Validation Accuracy", color=WHITE, fontweight="bold")
ax9.set_xlabel("Fold", color=WHITE); ax9.set_ylabel("Accuracy", color=WHITE)
ax9.set_xticks(range(1,6))
ax9.set_ylim(0.75, 0.92)
ax9.set_facecolor(DARK); ax9.tick_params(colors=WHITE)
for spine in ax9.spines.values(): spine.set_color("#334155")
ax9.legend(facecolor="#1e293b", labelcolor=WHITE, framealpha=0.8, ncol=4, fontsize=9)

plt.savefig("/mnt/user-data/outputs/churn_ml_report.png",
            dpi=150, bbox_inches="tight", facecolor=DARK)
print("   ✅  Report saved → churn_ml_report.png")

# ─────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────
print("\n" + "=" * 60)
print("  ✅  FINAL RESULTS SUMMARY")
print("=" * 60)
best = "Random Forest" if rf_acc >= lr_acc else "Logistic Regression"
best_acc = max(lr_acc, rf_acc)
print(f"""
  Model                 Accuracy    ROC-AUC
  ─────────────────────────────────────────
  Logistic Regression   {lr_acc:.4f}     {lr_auc:.4f}
  Random Forest         {rf_acc:.4f}     {rf_auc:.4f}

  🏆  Best Model : {best}
  📈  Accuracy   : {best_acc*100:.2f}%  ({'✅ TARGET MET' if best_acc >= 0.80 else '⚠️ Below 80%'})
  📋  Features   : {X.shape[1]}
  🗂️   Dataset    : {len(df):,} customers
""")
print("=" * 60)
